<?php
use Illuminate\Support\Facades\Route;

Route::namespace('App\Http\Controllers\Api\Auth\User')->group( function () {

//    Route::get('user/{id}', 'GetUserController');//Route::post('user', 'CreateUserController');
//    Route::put('user/{id}', 'UpdateUserController');
//    Route::delete('user/{id}', 'DeleteUserController');

});
