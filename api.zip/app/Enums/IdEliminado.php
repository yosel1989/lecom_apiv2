<?php

namespace App\Enums;

enum IdEliminado: int
{
    case Eliminado = 1;
    case NoEliminado = 0;
}
