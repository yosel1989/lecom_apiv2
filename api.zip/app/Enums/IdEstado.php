<?php

namespace App\Enums;

enum IdEstado: int
{
    case Inhabilitado = 0;
    case Habilitado = 1;
}
