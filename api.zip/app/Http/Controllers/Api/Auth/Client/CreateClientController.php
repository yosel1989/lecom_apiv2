<?php


namespace App\Http\Controllers\Api\Auth\Client;


class CreateClientController
{

}
